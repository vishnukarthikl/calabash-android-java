/**
 * Package that contains standard implementations for
 * {@link sh.calaba.org.codehaus.jackson.map.jsontype.TypeResolverBuilder}
 * and
 * {@link sh.calaba.org.codehaus.jackson.map.jsontype.TypeIdResolver}.
 *
 * @since 1.5
 */
package sh.calaba.org.codehaus.jackson.map.jsontype.impl;
