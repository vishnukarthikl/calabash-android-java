module Calabash
  module Android
    VERSION = "0.4.20"
  end
end
