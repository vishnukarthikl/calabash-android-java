module Calabash
  module Android
    VERSION = "0.4.21"
  end
end
