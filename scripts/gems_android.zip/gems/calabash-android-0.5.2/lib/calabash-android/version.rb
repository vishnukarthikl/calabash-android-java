module Calabash
  module Android
    VERSION = "0.5.2"
  end
end
