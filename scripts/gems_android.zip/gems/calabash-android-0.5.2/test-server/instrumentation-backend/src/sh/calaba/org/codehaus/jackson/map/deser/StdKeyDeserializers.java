package sh.calaba.org.codehaus.jackson.map.deser;

/**
 * @deprecated Since 1.9, use {@link sh.calaba.org.codehaus.jackson.map.deser.std.StdKeyDeserializers} instead.
 */
@Deprecated
class StdKeyDeserializers
    extends sh.calaba.org.codehaus.jackson.map.deser.std.StdKeyDeserializers
{
    protected StdKeyDeserializers() { super(); }
}
