module Calabash
  module Android
    VERSION = "0.4.18"
  end
end
