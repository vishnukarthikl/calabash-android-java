package com.jayway.android.robotium.solo;

import android.app.Activity;
import android.app.Instrumentation;

public class PublicViewFetcher extends ViewFetcher {

    public PublicViewFetcher(ActivityUtils activityUtils) {
        super(activityUtils);
    }
}
