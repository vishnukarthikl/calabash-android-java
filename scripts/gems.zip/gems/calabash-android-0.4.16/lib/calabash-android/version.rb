module Calabash
  module Android
    VERSION = "0.4.16"
  end
end
