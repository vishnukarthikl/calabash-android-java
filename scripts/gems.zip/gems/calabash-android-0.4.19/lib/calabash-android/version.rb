module Calabash
  module Android
    VERSION = "0.4.19"
  end
end
