/**
 * Annotations that directly depend on Mapper classes (not just
 * Jackson core) and are used for configuring Data Mapping functionality.
 */
package sh.calaba.org.codehaus.jackson.map.annotate;
