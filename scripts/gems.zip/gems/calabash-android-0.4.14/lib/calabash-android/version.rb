module Calabash
  module Android
    VERSION = "0.4.14"
  end
end
